<div class="container card_services">
  <h2>0UR SERVICES</h2>
  <div class="row">
    <div class="col-md-4 col-lg-4 col-sm-12">
        <div class="card">
            <div class="card-body">
                <img src="images/PIX 5.jpg" class="img-fluid">
            </div> 
            <div class="card-footer">Supply of electrical equipment</div>
        </div>
    </div>
    <div class="col-md-4 col-lg-4 col-sm-12">
        <div class="card">
         <div class="card-body">
            <img src="images/image5.png" class="img-fluid">
        </div> 
        <div class="card-footer">Assembly of electrical panels</div>
        </div>
  </div>
    <div class="col-md-4 col-lg-4 col-sm-12">
        <div class="card">
            <div class="card-body">
                <img src="images/image2.png" class="img-fluid">
            </div> 
            <div class="card-footer">Installation of electrical panels</div>
        </div>
    </div>
        <div class="col-md-4 col-lg-4 col-sm-12">
            <div class="card">
                <div class="card-body">
                    <img src="images/PIX 3.jpg" class="img-fluid">
                </div> 
                <div class="card-footer">Installation of transformers</div>
            </div>
        </div>
    <div class="col-md-4 col-lg-4 col-sm-12">
        <div class="card">
            <div class="card-body">
                <img src="images/PIX 2.jpg" class="img-fluid">
            </div> 
            <div class="card-footer">Maintenance  of electrical equipment</div>
        </div>
    </div>
    <div class="col-md-4 col-lg-4 col-sm-12">
        <div class="card">
            <div class="card-body">
                <img src="images/PIX 5.jpg" class="img-fluid">
        </div> 
        <div class="card-footer">supply  of electrical equipment</div>
        </div>
   </div>
  </div>
</div>