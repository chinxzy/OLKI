<div class="row about_vision m-auto">
   <div class="col-lg-6 col-md-6 col-sm-12 about">
        <h2>ABOUT US</h2>
        <p>OLKI   ELECTROMECHANICAL   NIG.LTD.   Is   an   indigenous   Electrical/Mechanical Engineering  Company
            established  in  2000  with  the  vision  to  diligently  excel 
            in  the  area  of supply  and  installation  of  electrical/mechanical  equipment,  
            especially  processing  control,
            High  Voltage  and  Low  Voltage  Switch  Gears,  maintenance,  
            testing  of  electrical/mechanical apparatus and electrical/mechanical installation works
            (both industrial/domestic).</p>
   </div>
   <div class="col-lg-6 col-md-6 col-sm-12 vision"> 
    <h2>OUR VISION</h2>
    <p>
    OLKI  ELECTROMECHANICAL NIG.LTD.  WILL STRIVE FOR THE BEST  
    <br>IN  THE FIELD OF ENGINEERING</br>
     <br>DRIVEN BY SHARED   COMMITMENTS TO EXCELLENCE,</br>
    CUSTOMER SATISFACTION AND CONTINOUS IMPROVEMENT.
    </p>
    <h2>OUR MISSION</h2>
    <p>“OLKI  will  be  engaged  in  engineering  services  
        <br>utilizing  manpower  and  CURRENT TECHNOLOGY”</br></p>
   </div>
  </div>
  <div class="row about_content m-auto">
    <div class="value col-lg-12 col-md-12 col-sm-12">
        <h2 class="overlay">OUR CORE VALUES</h2>
    </div>
      <div class="col-lg-6 col-md-6 col-sm-12 left">
            <h5>Professionalism</h5>
            <p>Our experience over the years in technical services delivery has taught us that only the
            best professional touch is good enough for our cherished customers.
            And we strive to do it right the first time all the time</p>

            <h5>Intergrity and Honesty</h5>
            <p>As a responsible corporate organization, we know that both professional integrity and
            honesty  are  the  twin  brothers  of  a  sustainable  organizational  growth  and
            success, hence, these have become our tag.</p>

            <h5>Openness and communication</h5>
            <p>Our  organization  has  leaped  from  strength  to  strength  due  to  the  inherent  positive 
            values  of  openness  and  communication;  it  has  helped  us  to  build  a  strong  team  of 
            multi-talented and creative professionals.<p>
        </div>

        <div class="col-lg-6 col-md-6 col-sm-12 right">
        <h5>Respect</h5>
            <p>Because  we  know  that  without  respect  forboth  our  clients  and  staff, 
            nothing worthwhile would be achieved.</p>

            <h5>Customer Satisfaction</h5> 
            <p>We  are  in  business  because  of  our  customers  and  therefore  it  is  
            our  responsibility  to  always  keep  them  satisfied  beyond  their  
            expectation  through  very  superior  technical service</p>

            <h5>Team spirit</h5>
            <p>The  result  achieved  by  all  members  of  our  team,  communicating 
             and  working
            together  would  always  be  superior  to  that  of  one  individual  that  
            is  why  we  cherish team work.</p>

            <h5>Promptness</h5>
            <p>Because we are only one dial away with the solutions to all your technical challenges; 
            we won’t be sleeping when our customers are losing money we won’t be sleeping when our 
            customers are losing money.</p>
        </div>
    </div>
</div>