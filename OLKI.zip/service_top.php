<div class="row m-auto">
<div class="col-lg-12 col-md-12 col-sm-12 service_top">
    <h2>Our Services Profile</h2>
    <h3>OLKI ELECTROMECHANICAL NIG.LTD. Offers her clients such services as follows:</h3>
    <p>Construction and installation works in Electrical and Mechanical Engineering fields.</p>
    <p>Estimating and assembling the cost of installation of Mechanical and Electrical Engineering System.</p>
    <p>Design and Supervision of Mechanical and Electrical Engineering System.</p>
    <p>Testing and Commissioning of Building and Industrial, Electrical and Mechanical Engineering System.</p>
</div>
</div>