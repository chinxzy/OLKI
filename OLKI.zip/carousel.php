<style>
  
</style>

<div class= "header row" style="margin-top:2%;">
    <div class = " container-fluid head col-sm-12" style="max-width: 50%" >
      <h1 class="size" style="margin-top:20%;"><span class="fast-flicker">Welcome to</span>  <span class="flicker">Olki</span></h1>
    </div>
</div>