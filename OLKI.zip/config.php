<?php

$smtpConfig = [
    "username" => "info@olkielectromechanical.com.ng",
    "password" => "QRZj%Znkd*Px",
    "incomingImapServer" => "mail.olkielectromechanical.com.ng",
    "incomingImapPort" =>  993,
    "outgoingImapServer" => "olkielectromechanical.com.ng",
    "outgoingImapPort" =>  587,

    // "outgoingImapServer" => "smtp.hostinger.com",
    // "outgoingImapPort" =>  587,
    // "username" => "otakon@outdoors.ng",
    // "password" => "otakonEmailPassword0000@@@@",
];

