<div class="row about_vision m-auto">
   <div class="col-lg-6 col-md-6 col-sm-12 about">
        <h2>ABOUT US</h2>
        <p>OLKI   ELECTROMECHANICAL   NIG.LTD.   Is   an   indigenous   Electrical/Mechanical Engineering  Company
            established  in  2000  with  the  vision  to  diligently  excel 
            in  the  area  of supply  and  installation  of  electrical/mechanical  equipment,  
            especially  processing  control,
            High  Voltage  and  Low  Voltage  Switch  Gears,  maintenance,  
            testing  of  electrical/mechanical apparatus and electrical/mechanical installation works
            (both industrial/domestic).</p>
   </div>
   <div class="col-lg-6 col-md-6 col-sm-12 vision"> 
    <h2>OUR VISION</h2>
    <p>
    OLKI  ELECTROMECHANICAL NIG.LTD.  WILL STRIVE FOR THE BEST  
    <br>IN  THE FIELD OF ENGINEERING</br>
     <br>DRIVEN BY SHARED   COMMITMENTS TO EXCELLENCE,</br>
    CUSTOMER SATISFACTION AND CONTINOUS IMPROVEMENT.
    </p>
    <h2>OUR MISSION</h2>
    <p>“OLKI  will  be  engaged  in  engineering  services  
        <br>utilizing  manpower  and  CURRENT TECHNOLOGY”</br></p>
   </div>
  </div>